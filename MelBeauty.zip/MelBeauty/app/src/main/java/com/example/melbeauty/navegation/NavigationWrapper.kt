package com.example.melbeauty.navigation

import androidx.compose.runtime.Composable
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import com.example.melbeauty.screens.LoginScreen
import com.example.melbeauty.screens.HomeScreen

@Composable
fun NavigationWrapper() {

    val backStack = rememberNavBackStack(Login)

    NavDisplay(
        backStack = backStack,

        onBack = {
            if (backStack.size > 1) {
                backStack.removeAt(backStack.lastIndex)
            }
        },

        entryProvider = entryProvider {

            entry<Login> {
                LoginScreen { usuario ->
                    backStack.add(Home(usuario))
                }
            }

            entry<Home> { pantalla ->
                HomeScreen(
                    usuario = pantalla.usuario,
                    onVolver = {
                        backStack.removeAt(backStack.lastIndex)
                    }
                )
            }
        }
    )
}
