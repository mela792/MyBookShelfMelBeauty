package com.example.melbeauty.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    usuario: String,
    onVolver: () -> Unit
) {

    val rosa = Color(0xFFF8BBD0)
    val crema = Color(0xFFFFF8F0)
    val marron = Color(0xFF5D4037)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(crema)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(modifier = Modifier.height(45.dp))

        Text(
            text = "MelBeauty",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = marron
        )

        Spacer(modifier = Modifier.height(35.dp))

        Text(
            text = "¡Bienvenida, $usuario!",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = marron
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Tu espacio de belleza",
            fontSize = 16.sp,
            color = marron
        )

        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "Nuestros servicios",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = marron
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {

            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(
                    containerColor = rosa
                )
            ) {
                Text("Peluquería", color = marron)
            }

            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(
                    containerColor = rosa
                )
            ) {
                Text("Manicura", color = marron)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {

            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(
                    containerColor = rosa
                )
            ) {
                Text("Maquillaje", color = marron)
            }

            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(
                    containerColor = rosa
                )
            ) {
                Text("Tratamientos", color = marron)
            }
        }

        Spacer(modifier = Modifier.height(35.dp))

        Text(
            text = "Tu belleza, nuestro compromiso",
            fontSize = 15.sp,
            color = marron
        )

        Spacer(modifier = Modifier.height(35.dp))

        Button(
            onClick = {
                onVolver()
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = rosa
            )
        ) {
            Text(
                text = "Volver al Login",
                color = marron
            )
        }
    }
}
